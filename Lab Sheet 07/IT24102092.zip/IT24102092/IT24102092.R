## Setting the directory
setwd("D:/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24102092")

getwd()

## Question 1
# Uniform Distribution

punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

## Question 2
# Exponential Distribution

pexp(2, rate = 1/3, lower.tail = TRUE)

## Question 3
# Normal Distribution

# Part 1
1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)

# Part 2
qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)




