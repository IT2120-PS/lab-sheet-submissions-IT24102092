# Part 1
# Set the working directory
setwd("D:/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24102092")
getwd()

# Import the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Part 2
Delivery_Times$Delivery_Time_.minutes. <- as.numeric(Delivery_Times$Delivery_Time_.minutes.)

hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = seq(20, 70, length = 10),
     right = TRUE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")

# Part 3
cf <- cumsum(table(cut(Delivery_Times$Delivery_Time_.minutes., breaks = seq(20, 70, by = 5), right = TRUE)))
cf

# Part 4
plot(seq(22.5, 67.5, by = 5), 
     cf, type = "o", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")



