## Setting the directory
setwd("D:/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24102092")
getwd()

## Question 1

# Part 1
# Binomial Distribution
# Here, random variable X has binomial distribution with n=50, p=0.85


# Part 2
# gives P(X >= 47) = 1 - P(X < 47) = 1 - P(X <= 46)
1 - pbinom(46, size=50, prob=0.85, lower.tail = TRUE)

## Question 2

# Part 1
# X = Number of customer calls received in one hour.

# Part 2
# Poisson distribution
# Here, random variable X has poisson distribution with lambda (λ) = 12

# Part 3
# Probability that exactly 15 calls are received in 1 hour
dpois(15, lambda = 12)

